---
name: portal-ui
description: UI component patterns for the Transplant Portal. Use when building dashboards, forms, modals, or any frontend UI work. This skill ensures consistency with approved prototype designs and healthcare UX standards.
---

# Portal UI Patterns

## When to Use This Skill

Use this skill when:
- Building any user-facing screens
- Creating role-based dashboards
- Implementing patient-facing flows
- Building modals or decision interfaces
- Styling forms, cards, or navigation
- Unsure about colors, spacing, or visual treatment

## Design Philosophy

This is a **HEALTHCARE application**. Every design choice must be:

- **Trustworthy**: Patients are scared. The UI should feel calm and professional.
- **Accessible**: WCAG 2.1 AA minimum. High contrast, readable fonts, clear focus states.
- **Clear**: No ambiguity. Status, next steps, and actions must be obvious.
- **Consistent**: Same patterns everywhere. Don't invent new UI for each screen.

## Portal-Specific Guidance

### Patient Portal

**CRITICAL: The prototype design is APPROVED. Replicate it exactly.**

Reference: `reference/patient-mobile/page.tsx` (3,933 lines, self-contained)

This prototype represents the approved visual design. Your job is to:
1. Build proper component architecture
2. Match the visual design exactly
3. Extract patterns into reusable components

Key characteristics:
- Mobile-first (max-width: 430px phone frame for demos)
- Soft, calming color palette (blues, light backgrounds)
- Rounded corners throughout (cards: 24px, buttons: full)
- Subtle shadows for depth, not harsh borders
- Bottom navigation (4 tabs: Home, Care Team, Profile, Help)
- Progress-focused UI (checklists, completion indicators)
- Full-width gradient CTA buttons

See: `references/patient-portal-patterns.md` for extracted values.

### Transplant Center Portal

Reference: `reference/transplant-prototype/components/`

Key characteristics:
- Desktop-first with responsive mobile
- Professional, data-dense dashboard aesthetic
- Sidebar navigation with role-based menu items
- Scannable data tables and queue lists
- Color-coded status indicators (SLA badges, stage pills)
- Modal-heavy workflow (decisions require explicit confirmation UI)
- Case cockpit as primary workspace (tabbed interface)

See: `references/center-portal-patterns.md` for component examples.

### Dialysis Clinic Portal

- Hybrid: desktop primary, tablet-friendly
- Simpler than center portal (fewer features)
- Focus on referral submission and status tracking
- Clean, minimal aesthetic
- Borrow patterns from center portal, simplify where possible

## Component Library

Use shadcn/ui components as the foundation:

```bash
npx shadcn-ui@latest add button card dialog table tabs badge input textarea select checkbox radio-group avatar dropdown-menu progress
```

Customize shadcn defaults to match portal-specific palettes. Do not use raw shadcn styling in patient portal - override with the approved color palette.

## Common Patterns

### SLA Status Badge

Used across all portals to indicate time-sensitivity:

```tsx
import { Badge } from '@/components/ui/badge';

function SLABadge({ daysRemaining }: { daysRemaining: number }) {
  const variant = daysRemaining > 2 ? 'success' 
    : daysRemaining > 0 ? 'warning' 
    : 'destructive';
  
  return (
    <Badge variant={variant} className="font-mono">
      {daysRemaining > 0 ? `${daysRemaining}d` : 'OVERDUE'}
    </Badge>
  );
}
```

### Role-Based Dashboard Queues

Center portal uses queue cards filtered by role:

```tsx
const ROLE_QUEUES: Record<Role, string[]> = {
  'front-desk': ['pending-ie-review', 'pending-doc-validation', 'ready-for-screening'],
  'ptc': ['my-cases', 'at-risk', 'pending-action'],
  'senior-coord': ['flagged-cases', 'escalations', 'decisions-needed'],
  'financial': ['pending-financial-review'],
  'specialist': ['pending-my-review'],
};

export function Dashboard({ role }: { role: Role }) {
  const queues = ROLE_QUEUES[role] ?? [];
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
      {queues.map(queue => <QueueCard key={queue} queueId={queue} />)}
    </div>
  );
}
```

### Decision Modal

Decision modals should feel **consequential**, not like default form dialogs:

```tsx
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';

function DecisionModal({ 
  decisionType, 
  outcomes, 
  onSubmit 
}: DecisionModalProps) {
  const [outcome, setOutcome] = useState<string>('');
  const [rationale, setRationale] = useState('');

  return (
    <Dialog>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Record Decision: {decisionType}</DialogTitle>
        </DialogHeader>
        <form onSubmit={(e) => { e.preventDefault(); onSubmit({ outcome, rationale }); }}>
          <RadioGroup value={outcome} onValueChange={setOutcome} className="space-y-3">
            {outcomes.map(o => (
              <div key={o.value} className="flex items-center space-x-3">
                <RadioGroupItem value={o.value} id={o.value} />
                <label htmlFor={o.value} className="text-sm font-medium">
                  {o.label}
                </label>
              </div>
            ))}
          </RadioGroup>
          <Textarea 
            placeholder="Rationale (required for some decisions)" 
            value={rationale}
            onChange={(e) => setRationale(e.target.value)}
            className="mt-4"
          />
          <DialogFooter className="mt-6">
            <Button type="submit" disabled={!outcome}>
              Record Decision
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
```

## What NOT to Do

- **Don't invent new color schemes** - use the established palettes
- **Don't use generic placeholder content** - use realistic healthcare data
- **Don't create empty shell UIs** - show meaningful states
- **Don't ignore mobile** - patient portal must work on phones
- **Don't use harsh colors in patient portal** - keep it calming
- **Don't copy page.tsx directly** - extract patterns into proper components
- **Don't use raw shadcn defaults in patient portal** - customize to match prototype

## Quick Reference

| Portal | Layout | Navigation | Primary Color | Reference |
|--------|--------|------------|---------------|-----------|
| Patient | Mobile-first | Bottom tabs | #3399e6 | `reference/patient-mobile/page.tsx` |
| Center | Desktop-first | Sidebar | Slate/neutral | `reference/transplant-prototype/` |
| Clinic | Desktop + tablet | Top nav | TBD (derive from center) | - |