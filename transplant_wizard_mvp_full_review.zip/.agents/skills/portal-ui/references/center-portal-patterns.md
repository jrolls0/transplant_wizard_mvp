# Transplant Center Portal UI Patterns

**Source of truth:** `reference/transplant-prototype/`

The center portal is the primary workspace for transplant coordinators, specialists, and administrative staff. It prioritizes efficiency, clarity, and workflow management.

## How to Use This Reference

1. Browse `reference/transplant-prototype/components/` for component examples
2. Check `reference/transplant-prototype/app/dashboard/` for page layouts
3. Use `reference/transplant-prototype/lib/data/` for data structure examples

## Design Principles

- **Data-dense but scannable**: Show more information, but organize it well
- **Role-aware**: Different roles see different dashboards and actions
- **Decision-focused**: Make the next action obvious
- **Status-forward**: SLA, stage, and flags should be immediately visible

## Color Palette

### Backgrounds
| Usage | Value |
|-------|-------|
| Page background | `bg-slate-50` or `bg-gray-50` |
| Card/surface | `bg-white` |
| Sidebar | `bg-slate-900` or `bg-slate-800` |

### Status Colors
| Status | Background | Text |
|--------|------------|------|
| On track | `bg-green-100` | `text-green-800` |
| At risk | `bg-yellow-100` | `text-yellow-800` |
| Overdue | `bg-red-100` | `text-red-800` |
| Neutral/info | `bg-blue-100` | `text-blue-800` |
| Ended | `bg-gray-100` | `text-gray-600` |

### Stage Colors (use consistently)
```tsx
const STAGE_COLORS: Record<CaseStage, string> = {
  'new-referral': 'bg-blue-100 text-blue-800',
  'patient-onboarding': 'bg-purple-100 text-purple-800',
  'initial-todos': 'bg-indigo-100 text-indigo-800',
  'follow-through': 'bg-cyan-100 text-cyan-800',
  'intermediary-step': 'bg-teal-100 text-teal-800',
  'initial-screening': 'bg-amber-100 text-amber-800',
  'financial-screening': 'bg-orange-100 text-orange-800',
  'records-collection': 'bg-lime-100 text-lime-800',
  'medical-records-review': 'bg-emerald-100 text-emerald-800',
  'specialist-review': 'bg-sky-100 text-sky-800',
  'final-decision': 'bg-violet-100 text-violet-800',
  'education': 'bg-pink-100 text-pink-800',
  'scheduling': 'bg-rose-100 text-rose-800',
  'scheduled': 'bg-green-100 text-green-800',
  'ended': 'bg-gray-100 text-gray-600',
};
```

## Layout Structure

### Main Layout

```tsx
<div className="flex h-screen">
  {/* Sidebar */}
  <aside className="w-64 bg-slate-900 text-white">
    <nav className="p-4 space-y-2">
      {navItems.map(item => <NavLink key={item.href} {...item} />)}
    </nav>
  </aside>
  
  {/* Main content */}
  <main className="flex-1 overflow-auto">
    <header className="border-b bg-white px-6 py-4">
      <h1 className="text-xl font-semibold">{pageTitle}</h1>
    </header>
    <div className="p-6">
      {children}
    </div>
  </main>
</div>
```

### Role-Based Dashboards

Each role sees a customized dashboard with relevant queues:

```tsx
// Front Desk
<DashboardGrid>
  <QueueCard title="Pending I/E Review" filter={{ taskType: 'review-ie-responses' }} />
  <QueueCard title="Docs to Validate" filter={{ taskType: 'review-document' }} />
  <QueueCard title="Ready for Screening" filter={{ stage: 'initial-screening' }} />
</DashboardGrid>

// Senior Coordinator
<DashboardGrid>
  <QueueCard title="Flagged Cases" filter={{ hasFlag: true }} />
  <QueueCard title="Decisions Needed" filter={{ hasPendingDecision: true }} />
  <QueueCard title="Escalations" filter={{ escalated: true }} />
</DashboardGrid>

// PTC (Patient Transplant Coordinator)
<DashboardGrid>
  <QueueCard title="My Cases" filter={{ assignedTo: currentUser.id }} />
  <QueueCard title="At Risk" filter={{ slaStatus: 'at-risk' }} />
  <QueueCard title="Unassigned" filter={{ assignedTo: null }} />
</DashboardGrid>
```

## Case Cockpit

The case cockpit is the primary workspace for viewing and managing a single case.

### Tab Structure

```tsx
const COCKPIT_TABS = [
  { id: 'overview', label: 'Overview', icon: FileText },
  { id: 'timeline', label: 'Timeline', icon: Clock },
  { id: 'documents', label: 'Documents', icon: Folder },
  { id: 'tasks', label: 'Tasks', icon: CheckSquare },
  { id: 'messages', label: 'Messages', icon: MessageSquare },
  { id: 'decisions', label: 'Decisions', icon: Scale },
];

<Tabs defaultValue="overview">
  <TabsList className="border-b w-full justify-start rounded-none bg-transparent p-0">
    {COCKPIT_TABS.map(tab => (
      <TabsTrigger
        key={tab.id}
        value={tab.id}
        className="border-b-2 border-transparent data-[state=active]:border-primary"
      >
        <tab.icon className="mr-2 h-4 w-4" />
        {tab.label}
      </TabsTrigger>
    ))}
  </TabsList>
  
  <TabsContent value="overview">
    <CaseOverview case={caseData} />
  </TabsContent>
  {/* ... other tabs */}
</Tabs>
```

### Case Header

Always visible at top of cockpit:

```tsx
<div className="flex items-center justify-between border-b bg-white p-4">
  <div>
    <div className="flex items-center gap-3">
      <h1 className="text-xl font-bold">{caseData.caseNumber}</h1>
      <StageBadge stage={caseData.stage} />
      <SLABadge daysRemaining={caseData.slaDaysRemaining} />
    </div>
    <p className="text-sm text-slate-600">
      {caseData.patient.name} | {caseData.referringClinicName}
    </p>
  </div>
  <div className="flex items-center gap-2">
    {caseData.flags.map(flag => <FlagBadge key={flag} flag={flag} />)}
    <ActionDropdown caseId={caseData.id} />
  </div>
</div>
```

## Modal Patterns

### Standard Decision Modal

```tsx
<Dialog open={isOpen} onOpenChange={setIsOpen}>
  <DialogContent className="sm:max-w-lg">
    <DialogHeader>
      <DialogTitle className="flex items-center gap-2">
        <Scale className="h-5 w-5" />
        {modalTitle}
      </DialogTitle>
      <DialogDescription>
        {modalDescription}
      </DialogDescription>
    </DialogHeader>
    
    <div className="space-y-4 py-4">
      <RadioGroup value={selectedOutcome} onValueChange={setSelectedOutcome}>
        {outcomes.map(outcome => (
          <div key={outcome.value} className="flex items-start space-x-3 rounded-lg border p-3 hover:bg-slate-50">
            <RadioGroupItem value={outcome.value} id={outcome.value} className="mt-1" />
            <div>
              <label htmlFor={outcome.value} className="font-medium">
                {outcome.label}
              </label>
              <p className="text-sm text-slate-500">{outcome.description}</p>
            </div>
          </div>
        ))}
      </RadioGroup>
      
      <div className="space-y-2">
        <label className="text-sm font-medium">
          Rationale {requiresRationale && <span className="text-red-500">*</span>}
        </label>
        <Textarea
          value={rationale}
          onChange={(e) => setRationale(e.target.value)}
          placeholder="Document your reasoning..."
          rows={3}
        />
      </div>
    </div>
    
    <DialogFooter>
      <Button variant="outline" onClick={() => setIsOpen(false)}>
        Cancel
      </Button>
      <Button onClick={handleSubmit} disabled={!selectedOutcome || (requiresRationale && !rationale)}>
        Record Decision
      </Button>
    </DialogFooter>
  </DialogContent>
</Dialog>
```

### Confirmation Modal (for destructive actions)

```tsx
<AlertDialog>
  <AlertDialogContent>
    <AlertDialogHeader>
      <AlertDialogTitle className="flex items-center gap-2 text-red-600">
        <AlertTriangle className="h-5 w-5" />
        End Referral
      </AlertDialogTitle>
      <AlertDialogDescription>
        This action cannot be undone. The case will be marked as ended and a letter will be generated.
      </AlertDialogDescription>
    </AlertDialogHeader>
    <AlertDialogFooter>
      <AlertDialogCancel>Cancel</AlertDialogCancel>
      <AlertDialogAction className="bg-red-600 hover:bg-red-700">
        End Referral
      </AlertDialogAction>
    </AlertDialogFooter>
  </AlertDialogContent>
</AlertDialog>
```

## Table Patterns

### Case List Table

```tsx
<Table>
  <TableHeader>
    <TableRow>
      <TableHead className="w-[120px]">Case #</TableHead>
      <TableHead>Patient</TableHead>
      <TableHead>Stage</TableHead>
      <TableHead>SLA</TableHead>
      <TableHead>Assigned To</TableHead>
      <TableHead>Flags</TableHead>
      <TableHead className="w-[80px]"></TableHead>
    </TableRow>
  </TableHeader>
  <TableBody>
    {cases.map(caseItem => (
      <TableRow key={caseItem.id} className="cursor-pointer hover:bg-slate-50">
        <TableCell className="font-mono font-medium">{caseItem.caseNumber}</TableCell>
        <TableCell>{caseItem.patient.name}</TableCell>
        <TableCell><StageBadge stage={caseItem.stage} /></TableCell>
        <TableCell><SLABadge daysRemaining={caseItem.slaDaysRemaining} /></TableCell>
        <TableCell>{caseItem.assignedPTC?.name ?? 'Unassigned'}</TableCell>
        <TableCell>
          <div className="flex gap-1">
            {caseItem.flags.slice(0, 2).map(f => <FlagBadge key={f} flag={f} size="sm" />)}
            {caseItem.flags.length > 2 && (
              <Badge variant="outline">+{caseItem.flags.length - 2}</Badge>
            )}
          </div>
        </TableCell>
        <TableCell>
          <Button variant="ghost" size="sm">
            <ChevronRight className="h-4 w-4" />
          </Button>
        </TableCell>
      </TableRow>
    ))}
  </TableBody>
</Table>
```

## Queue Card Pattern

```tsx
function QueueCard({ title, count, filter, icon: Icon }: QueueCardProps) {
  return (
    <Card className="cursor-pointer transition hover:shadow-md">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-slate-600">
          {title}
        </CardTitle>
        <Icon className="h-4 w-4 text-slate-400" />
      </CardHeader>
      <CardContent>
        <div className="text-3xl font-bold">{count}</div>
        <p className="text-xs text-slate-500 mt-1">
          {count === 1 ? 'case' : 'cases'} in queue
        </p>
      </CardContent>
    </Card>
  );
}
```

## Key Files to Reference

```
reference/transplant-prototype/
├── components/
│   ├── modals/
│   │   ├── ScreeningRoutingModal.tsx    # Decision modal pattern
│   │   ├── EndReferralModal.tsx         # Confirmation pattern
│   │   └── ...
│   ├── case-cockpit/
│   │   ├── CockpitHeader.tsx
│   │   ├── OverviewTab.tsx
│   │   ├── TimelineTab.tsx
│   │   └── ...
│   └── dashboard/
│       ├── QueueCard.tsx
│       └── CaseTable.tsx
├── app/
│   └── dashboard/
│       ├── front-desk/page.tsx
│       ├── ptc/page.tsx
│       └── senior-coord/page.tsx
└── lib/
    ├── data/
    │   ├── stages.ts                    # Stage definitions
    │   └── endReasons.ts                # End reason codes
    └── context/
        └── CaseContext.tsx              # State management pattern
```