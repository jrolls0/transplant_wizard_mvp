# Patient Portal UI Patterns

**Source of truth:** `reference/patient-mobile/page.tsx`

The patient portal prototype is APPROVED. When implementing patient-facing UI, match this design exactly.

## How to Use This Reference

1. Grep `reference/patient-mobile/page.tsx` for working examples
2. Use the values below for consistency
3. When in doubt, look at the prototype

## Color Palette

### Backgrounds
| Usage | Value | Example |
|-------|-------|---------|
| Page background | `bg-[#f0f5fb]` or `bg-[#f4f7fb]` | Outer page wrapper |
| Card surface | `bg-white` or `bg-white/95` | Content cards |
| Onboarding gradient | `bg-gradient-to-br from-[#f2f7ff] via-[#ecf3ff] to-[#e2edf8]` | Login/consent screens |

### Primary Blue
| Usage | Value | Example |
|-------|-------|---------|
| Primary buttons, icons | `bg-[#3399e6]` | CTA buttons, active icons |
| Primary text on light | `text-[#2a6ead]` | Links, info text |
| Info card background | `bg-[#edf5ff]` | Informational callouts |
| Button glow shadow | `shadow-[0_10px_24px_rgba(51,153,230,0.35)]` | Primary button elevation |

### Status Colors
| Usage | Value | Example |
|-------|-------|---------|
| Success/complete | `text-green-500`, `bg-green-500` | Checkmarks, completed items |
| Warning/pending | `text-amber-500`, `bg-amber-500` | Attention needed |
| Danger/error | `bg-[#ef4444]` | Error badges, alerts |

### Borders & Neutrals
| Usage | Value | Example |
|-------|-------|---------|
| Input borders | `border-[#dde7f2]` | Form inputs, cards |
| Dividers | `border-[#e3ebf5]` or `border-[#dce7f2]` | Section separators |
| Primary text | `text-slate-900` | Headings |
| Secondary text | `text-slate-500` or `text-slate-600` | Descriptions |
| Muted text | `text-slate-400` | Placeholders |

## Typography

```tsx
// Headings
<h1 className="text-[31px] font-bold tracking-tight text-slate-900">

// Section labels
<span className="text-xs font-semibold uppercase tracking-wide text-slate-500">

// Body text
<p className="text-sm text-slate-600">

// Button text
<button className="text-base font-semibold">
```

Font stack: Inter, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif

## Spacing & Sizing

- Page padding: `px-4` or `px-5`
- Card padding: `p-4`
- Standard gaps: `gap-1`, `gap-2`, `gap-4`
- Section spacing: `space-y-4`

## Border Radius

| Element | Value |
|---------|-------|
| Cards, elevated surfaces | `rounded-[24px]` |
| Buttons | `rounded-full` |
| Inputs | `rounded-xl` |
| Info cards, small elements | `rounded-xl` |
| Badges | `rounded-full` |

## Shadows

| Usage | Value |
|-------|-------|
| Phone frame (demo) | `shadow-[0_28px_60px_rgba(15,23,42,0.24)]` |
| Elevated cards | `shadow-[0_20px_40px_rgba(15,23,42,0.11)]` |
| Floating elements | `shadow-[0_8px_18px_rgba(15,23,42,0.08)]` |
| Primary button | `shadow-[0_10px_24px_rgba(51,153,230,0.35)]` |

## Component Snippets

### Bottom Navigation

```tsx
<nav className="fixed bottom-0 left-0 right-0 border-t border-[#dce7f2] bg-white px-2 py-2">
  <div className="grid grid-cols-4 gap-1">
    {tabs.map(tab => (
      <button
        key={tab.id}
        onClick={() => setActiveTab(tab.id)}
        className={`flex flex-col items-center py-2 ${
          activeTab === tab.id ? 'text-[#3399e6]' : 'text-slate-400'
        }`}
      >
        <tab.icon className="h-5 w-5" />
        <span className="text-[10px] font-semibold">{tab.label}</span>
      </button>
    ))}
  </div>
</nav>
```

### Elevated Card

```tsx
<div className="rounded-[24px] bg-white/95 p-4 shadow-[0_20px_40px_rgba(15,23,42,0.11)]">
  {children}
</div>
```

### Primary Button

```tsx
<button className="w-full rounded-full bg-[#3399e6] py-4 text-base font-semibold text-white shadow-[0_10px_24px_rgba(51,153,230,0.35)] transition hover:bg-[#2a8ad4] disabled:opacity-50">
  Continue
</button>
```

### Secondary/Outline Button

```tsx
<button className="w-full rounded-full border border-[#dde7f2] bg-white py-4 text-base font-semibold text-slate-700 transition hover:bg-slate-50">
  Cancel
</button>
```

### Info Card

```tsx
<div className="rounded-xl bg-[#edf5ff] px-3 py-2 text-xs text-[#2a6ead]">
  <InfoIcon className="mr-1 inline h-3 w-3" />
  Information message here
</div>
```

### Form Input

```tsx
<div className="space-y-1.5">
  <label className="text-xs font-semibold uppercase tracking-wide text-slate-500">
    Email Address
  </label>
  <input
    type="email"
    className="w-full rounded-xl border border-[#dde7f2] bg-white px-4 py-3.5 text-base outline-none transition focus:border-[#3399e6] focus:ring-2 focus:ring-[#3399e6]/20"
    placeholder="you@example.com"
  />
</div>
```

### Todo/Checklist Item

```tsx
<div className={`flex items-center gap-3 rounded-xl p-3 ${
  completed ? 'bg-green-50' : 'bg-white border border-[#dde7f2]'
}`}>
  <div className={`flex h-6 w-6 items-center justify-center rounded-full ${
    completed ? 'bg-green-500 text-white' : 'border-2 border-slate-300'
  }`}>
    {completed && <Check className="h-4 w-4" />}
  </div>
  <div className="flex-1">
    <p className={`font-medium ${completed ? 'text-slate-500 line-through' : 'text-slate-900'}`}>
      {title}
    </p>
    <p className="text-xs text-slate-500">{description}</p>
  </div>
  <ChevronRight className="h-5 w-5 text-slate-400" />
</div>
```

## Key Screens

When building these screens, grep page.tsx for the implementation:

1. **Entry/Login** - `grep -n "EntryAuthTab\|'register'\|'login'" page.tsx`
2. **Consent screens** - `grep -n "Consent\|consent" page.tsx`
3. **Home dashboard** - `grep -n "home.*tab\|TodoCard" page.tsx`
4. **Health questionnaire** - `grep -n "Questionnaire\|questionnaire" page.tsx`
5. **Document upload** - `grep -n "upload\|Upload" page.tsx`
6. **Care team/Messages** - `grep -n "careTeam\|Message" page.tsx`

## Icons

Use lucide-react exclusively. Common patient portal icons:

```tsx
import {
  House,           // Home tab
  Users,           // Care Team tab
  UserRound,       // Profile tab
  CircleHelp,      // Help tab
  Bell,            // Notifications
  Check,           // Completed state
  CheckCircle2,    // Success
  ChevronRight,    // Navigation arrow
  ArrowLeft,       // Back button
  FileText,        // Documents
  Clock3,          // Pending/time
  Heart,           // Health-related
} from 'lucide-react';
```