# Working Memory

Last updated: [DATE]

## Current Milestone
Milestone 1: Workspace hardening

## Status
- **Completed**: Initial Codex workspace structure created
- **In Progress**: Hardening workspace for long-running Codex sessions
- **Blocked**: None

## What Was Completed
- Core skills added (transplant-workflow, portal-ui, supabase-patterns)
- Agent configs added (planner, reviewer, database-architect, tester)
- Reference folders added with prototype code
- File-backed memory structure established

## What Is In Progress
- Finalizing AGENTS.md
- Establishing execution workflow

## Next Step
1. Finalize AGENTS.md content
2. Run initial Codex session to validate workspace loads correctly
3. Decide first product implementation milestone

## Key Decisions
| Decision | Rationale | ADR |
|----------|-----------|-----|
| AGENTS.md for stable rules only | Prevents context rot from appending state | - |
| WORKING_MEMORY.md for evolving state | Separates ephemeral from durable | - |
| ACTIVE_PLAN.md as execution source | Single place for current milestone | - |
| Reference folder is read-only | Protects prototype code from accidental edits | - |
| Next.js + Supabase + Vercel | Best fit for HIPAA SaaS with fast iteration | 001 |

## Known Risks
- No production app code yet
- No database schema created yet
- Hard gates not yet implemented

## Open Questions
- What is the first product implementation milestone?
- Should we start with schema or with a single portal?

## Important Commands
```bash
# Start Codex
codex

# Check recent changes
git log --oneline -10

# Compact context
/compact

# Check workspace status
/status
```

## Key File Locations
| Purpose | Location |
|---------|----------|
| Stable rules | `AGENTS.md` |
| Full spec | `docs/HANDOFF.md` |
| Original requirements | `docs/WORKFLOW_SPEC.md` |
| Current state | `docs/WORKING_MEMORY.md` |
| Durable patterns | `docs/LEARNINGS.md` |
| Active execution | `plans/ACTIVE_PLAN.md` |
| Execution runbook | `docs/IMPLEMENT.md` |
| ADRs | `docs/decisions/` |
| Skills | `.agents/skills/` |
| Agent configs | `agents/` |
| Prototypes | `reference/` |