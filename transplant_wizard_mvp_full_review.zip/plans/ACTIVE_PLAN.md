# Active Plan

This is the execution source of truth. One milestone at a time.

---

## Current Goal
Set up a durable Codex workspace for Transplant Wizard MVP with file-backed memory and milestone-based execution.

---

## Milestone 1: Workspace Hardening ✅
**Status**: Complete

### Acceptance Criteria
- [x] Working memory file exists (`docs/WORKING_MEMORY.md`)
- [x] Implementation runbook exists (`docs/IMPLEMENT.md`)
- [x] Subtree override files exist (`reference/`, `src/`, `supabase/`)
- [x] Root `.gitignore` exists
- [x] Skills and agent configs finalized
- [x] LEARNINGS.md template created

### Validation
- Codex can summarize workspace correctly
- All instruction files are referenced

---

## Milestone 2: First Product Implementation
**Status**: Not started

### Goal
[TBD - Define the first concrete build milestone]

### Acceptance Criteria
- [ ] [TBD]

### Files Likely to Change
- [TBD]

### Validation
- [TBD]

### Risks
- [TBD]

---

## Milestone Template

Copy this for future milestones:
```markdown
## Milestone N: [Title]
**Status**: Not started | In progress | Complete

### Goal
[One sentence describing what this milestone achieves]

### Acceptance Criteria
- [ ] [Specific, verifiable criteria]

### Files Likely to Change
- [List of files/directories]

### Validation
- [Commands to run]
- [What success looks like]

### Dependencies
- [What must be done first]

### Risks
- [What could go wrong]
```

---

## Decision Log
- Keep `AGENTS.md` stable (no temporary state)
- Put evolving progress in `docs/WORKING_MEMORY.md`
- Put active execution details in this file
- Create ADRs for durable architectural decisions

---

## Stop-and-Fix Rule
If validation fails, fix before moving to the next milestone. Do not skip.